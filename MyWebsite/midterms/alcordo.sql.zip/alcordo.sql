-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 11, 2019 at 05:05 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alcordo`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_address`
--

CREATE TABLE `tbl_address` (
  `addID` int(11) NOT NULL,
  `blockNum` varchar(10) NOT NULL,
  `streetName` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `addType` varchar(20) NOT NULL,
  `nameID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_address`
--

INSERT INTO `tbl_address` (`addID`, `blockNum`, `streetName`, `city`, `addType`, `nameID`) VALUES
(1, 'Sample', 'Sample', 'Sample', 'Sample', 1),
(2, 'Sample', 'Sample', 'Sample', 'Sample', 2),
(3, 'Sample', 'Sample', 'Sample', 'Sample', 1),
(4, 'Sample', 'Sample', 'Sample', 'Sample', 2),
(5, 'Sample', 'Sample', 'Sample', 'Sample', 3),
(6, 'Sample', 'Sample', 'Sample', 'Sample', 4),
(7, 'Sample', 'Sample', 'Sample', 'Sample', 5),
(8, 'Sample', 'Sample', 'Sample', 'Sample', 6),
(9, 'Sample', 'Sample', 'Sample', 'Sample', 7),
(10, 'Sample', 'Sample', 'Sample', 'Sample', 8),
(11, 'Sample', 'Sample', 'Sample', 'Sample', 9),
(12, 'Sample', 'Sample', 'Sample', 'Sample', 10),
(13, 'Sample', 'Sample', 'Sample', 'Sample', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_names`
--

CREATE TABLE `tbl_names` (
  `nameID` int(11) NOT NULL,
  `firstName` varchar(30) NOT NULL,
  `midName` varchar(30) NOT NULL,
  `lastName` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_names`
--

INSERT INTO `tbl_names` (`nameID`, `firstName`, `midName`, `lastName`) VALUES
(1, 'Sample', 'Sample', 'Sample'),
(2, 'Sample', 'Sample', 'Sample'),
(3, 'Sample', 'Sample', 'Sample'),
(4, 'Sample', 'Sample', 'Sample'),
(5, 'Sample', 'Sample', 'Sample'),
(6, 'Sample', 'Sample', 'Sample'),
(7, 'Sample', 'Sample', 'Sample'),
(8, 'Sample', 'Sample', 'Sample'),
(9, 'Sample', 'Sample', 'Sample'),
(10, 'Sample', 'Sample', 'Sample'),
(11, 'Sample', 'Sample', 'Sample'),
(12, 'Sample', 'Sample', 'Sample'),
(13, 'Sample', 'Sample', 'Sample'),
(14, 'Sample', 'Sample', 'Sample'),
(15, 'Sample', 'Sample', 'Sample'),
(16, 'Sample', 'Sample', 'Sample'),
(17, 'Sample', 'Sample', 'Sample'),
(18, 'Sample', 'Sample', 'Sample'),
(19, 'Sample', 'Sample', 'Sample'),
(20, 'Sample', 'Sample', 'Sample'),
(21, 'Sample', 'Sample', 'Sample'),
(22, 'Sample', 'Sample', 'Sample');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_address`
--
ALTER TABLE `tbl_address`
  ADD PRIMARY KEY (`addID`),
  ADD KEY `nameID` (`nameID`);

--
-- Indexes for table `tbl_names`
--
ALTER TABLE `tbl_names`
  ADD PRIMARY KEY (`nameID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_address`
--
ALTER TABLE `tbl_address`
  MODIFY `addID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_names`
--
ALTER TABLE `tbl_names`
  MODIFY `nameID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_address`
--
ALTER TABLE `tbl_address`
  ADD CONSTRAINT `tbl_address_ibfk_1` FOREIGN KEY (`nameID`) REFERENCES `tbl_names` (`nameID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
